package ui.datamodels.pim;

import utilities.JsonHandler;

public class PIMSearchDataModel
{
	JsonHandler objJsonHandler = new JsonHandler();
	String filepath = "C:\\Users\\sarvani.shk\\eclipse-workspace\\testng\\src\\main\\resources\\pagelocators\\pim\\PIMAddData.json";

	public String employeeNameData()
	{
		String employeeNameData = objJsonHandler.valuesFromJson(filepath, "constants", "EmployeeName_Txt");
		return employeeNameData;
	}
}
