package uicontrollers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class UIActions
{
	ElementFinder objElementFinder = new ElementFinder();

	public void setText(WebElement element, String value)
	{
		try
		{
			if (element != null)
			{
				element.sendKeys(value);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public void clickOnElement(WebElement element, WebDriver driver)
	{
		try
		{
			if (element != null)
			{
				objElementFinder.waitForElementToBeClickable(driver, element);
				element.click();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
